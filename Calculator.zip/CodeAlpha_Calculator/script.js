// ---------- state ----------
let currentInput = '0';
let previousValue = null;
let operator = null;
let overwrite = true; // next digit press should start a fresh number

const currentEl = document.getElementById('current');
const historyEl = document.getElementById('history');

// ---------- helpers ----------
function formatNumber(numStr){
  if (numStr === 'Error') return numStr;
  const [intPart, decPart] = numStr.split('.');
  const formattedInt = Number(intPart).toLocaleString('en-US');
  return decPart !== undefined ? `${formattedInt}.${decPart}` : formattedInt;
}

function updateDisplay(){
  currentEl.textContent = formatNumber(currentInput);
  currentEl.classList.toggle('error', currentInput === 'Error');

  if (operator && previousValue !== null){
    historyEl.textContent = `${formatNumber(previousValue)} ${operatorSymbol(operator)}`;
  } else {
    historyEl.textContent = '';
  }

  document.querySelectorAll('.key.op').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.op === operator);
  });
}

function operatorSymbol(op){
  return { add:'+', subtract:'−', multiply:'×', divide:'÷' }[op] || '';
}

function compute(a, b, op){
  a = parseFloat(a);
  b = parseFloat(b);
  switch(op){
    case 'add': return a + b;
    case 'subtract': return a - b;
    case 'multiply': return a * b;
    case 'divide': return b === 0 ? null : a / b;
    default: return b;
  }
}

function trimResult(num){
  if (num === null || !isFinite(num)) return 'Error';
  // avoid floating point artifacts, cap precision
  let result = Math.round((num + Number.EPSILON) * 1e10) / 1e10;
  return String(result);
}

// ---------- input handlers ----------
function inputDigit(digit){
  if (currentInput === 'Error' || overwrite){
    currentInput = digit;
    overwrite = false;
  } else {
    if (currentInput.replace('-','').length >= 14) return; // avoid overflow
    currentInput = currentInput === '0' ? digit : currentInput + digit;
  }
  updateDisplay();
}

function inputDecimal(){
  if (currentInput === 'Error' || overwrite){
    currentInput = '0.';
    overwrite = false;
    updateDisplay();
    return;
  }
  if (!currentInput.includes('.')) {
    currentInput += '.';
    updateDisplay();
  }
}

function chooseOperator(op){
  if (currentInput === 'Error') return;

  if (operator !== null && !overwrite){
    // chain: compute pending operation first
    const result = compute(previousValue, currentInput, operator);
    const resultStr = trimResult(result);
    previousValue = resultStr;
    currentInput = resultStr;
  } else {
    previousValue = currentInput;
  }

  operator = op;
  overwrite = true;
  updateDisplay();
}

function calculate(){
  if (operator === null || previousValue === null || currentInput === 'Error') return;
  const result = compute(previousValue, currentInput, operator);
  const resultStr = trimResult(result);

  historyEl.textContent = `${formatNumber(previousValue)} ${operatorSymbol(operator)} ${formatNumber(currentInput)} =`;
  currentInput = resultStr;
  previousValue = null;
  operator = null;
  overwrite = true;

  currentEl.textContent = formatNumber(currentInput);
  currentEl.classList.toggle('error', currentInput === 'Error');
  document.querySelectorAll('.key.op').forEach(btn => btn.classList.remove('active'));
}

function clearAll(){
  currentInput = '0';
  previousValue = null;
  operator = null;
  overwrite = true;
  updateDisplay();
}

function deleteLast(){
  if (currentInput === 'Error' || overwrite) { clearAll(); return; }
  currentInput = currentInput.length > 1 ? currentInput.slice(0, -1) : '0';
  if (currentInput === '-') currentInput = '0';
  updateDisplay();
}

function toggleSign(){
  if (currentInput === 'Error' || currentInput === '0') return;
  currentInput = currentInput.startsWith('-') ? currentInput.slice(1) : '-' + currentInput;
  updateDisplay();
}

function percent(){
  if (currentInput === 'Error') return;
  currentInput = trimResult(parseFloat(currentInput) / 100);
  updateDisplay();
}

// ---------- wire up buttons ----------
document.querySelectorAll('.key[data-digit]').forEach(btn => {
  btn.addEventListener('click', () => inputDigit(btn.dataset.digit));
});
document.querySelectorAll('.key[data-op]').forEach(btn => {
  btn.addEventListener('click', () => chooseOperator(btn.dataset.op));
});
document.getElementById('decimalBtn').addEventListener('click', inputDecimal);
document.getElementById('equalsBtn').addEventListener('click', calculate);
document.getElementById('clearBtn').addEventListener('click', clearAll);
document.getElementById('deleteBtn').addEventListener('click', deleteLast);
document.getElementById('percentBtn').addEventListener('click', percent);

// ---------- keyboard support (bonus) ----------
const opKeyMap = { '+':'add', '-':'subtract', '*':'multiply', '/':'divide' };

window.addEventListener('keydown', e => {
  if (e.key >= '0' && e.key <= '9'){ inputDigit(e.key); flashKey(`[data-digit="${e.key}"]`); return; }
  if (e.key === '.'){ inputDecimal(); flashKey('#decimalBtn'); return; }
  if (opKeyMap[e.key]){ chooseOperator(opKeyMap[e.key]); flashKey(`[data-op="${opKeyMap[e.key]}"]`); return; }
  if (e.key === 'Enter' || e.key === '='){ e.preventDefault(); calculate(); flashKey('#equalsBtn'); return; }
  if (e.key === 'Backspace'){ deleteLast(); flashKey('#deleteBtn'); return; }
  if (e.key === 'Escape'){ clearAll(); flashKey('#clearBtn'); return; }
  if (e.key === '%'){ percent(); flashKey('#percentBtn'); return; }
});

function flashKey(selector){
  const el = document.querySelector(selector);
  if (!el) return;
  el.style.transform = 'translateY(2px)';
  setTimeout(() => { el.style.transform = ''; }, 100);
}

updateDisplay();
